//
//  ViewController.h
//  BabyBluetoothAppDemo
//
//  Created by 刘彦玮 on 15/8/1.
//  Copyright (c) 2015年 刘彦玮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "BabyBluetooth.h"

@interface ViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>

@property(strong,nonatomic)CBPeripheral *currPeripheral;
@property (nonatomic, weak) IBOutlet UITableView *tableView;

@end

