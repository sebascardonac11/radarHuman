//
//  BaseViewController.m
//  HLKRadarTool
//
//  Created by 佐文周 on 2022/9/21.
//  Copyright © 2022 刘彦玮. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];


}

- (void)backAction {
    [self.navigationController popViewControllerAnimated:YES];
}




@end
