//
//  ZZW_NavViewController.h
//  Kaisi_TimingDevice
//
//  Created by mqw on 2021/9/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZZW_NavViewController : UINavigationController

@end

NS_ASSUME_NONNULL_END
